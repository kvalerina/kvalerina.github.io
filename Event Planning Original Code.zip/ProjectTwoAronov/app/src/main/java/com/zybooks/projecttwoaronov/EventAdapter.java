package com.zybooks.projecttwoaronov;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Objects;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private final List<Event> eventList;
    private final Context context;

    // Constructor
    public EventAdapter(Context context, List<Event> eventList) {
        this.context = context;
        this.eventList = eventList;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_card, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);

        // Bind data to views
        holder.eventTitle.setText(event.getTitle());
        holder.eventTime.setText(event.getTime());
        holder.eventDescription.setText(event.getDescription());

        // Handle ellipsis button click
        holder.moreOptions.setOnClickListener(v -> {
            PopupMenu popupMenu = new PopupMenu(context, holder.moreOptions);
            popupMenu.inflate(R.menu.event_options_menu); // Ensure the menu exists

            popupMenu.setOnMenuItemClickListener(item -> handleMenuItemClick(item, event, position));
            popupMenu.show();
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    // Handle menu item clicks
    private boolean handleMenuItemClick(MenuItem item, Event event, int position) {
        String selectedOption = Objects.requireNonNull(item.getTitle()).toString();

        if (selectedOption.equals("Edit Event")) {
            Intent intent = new Intent(context, EditEventActivity.class);
            intent.putExtra("eventId", event.getId()); // Pass event ID to EditEventActivity
            context.startActivity(intent); // Ensure context is an Activity or replace it with itemView.getContext()
            return true;
        } else if (selectedOption.equals("Delete Event")) {
            deleteEvent(event, position);
            return true;
        }
        return false;
    }

    // Edit an event
    private void editEvent(Event event) {
        Intent intent = new Intent(context, EditEventActivity.class);
        intent.putExtra("event_id", event.getId());
        intent.putExtra("event_name", event.getTitle());
        intent.putExtra("event_date", event.getDate());
        intent.putExtra("event_time", event.getTime());
        intent.putExtra("event_description", event.getDescription());
        context.startActivity(intent);
    }

    // Delete an event
    private void deleteEvent(Event event, int position) {
        DatabaseHelper db = new DatabaseHelper(context);
        boolean isDeleted = db.deleteEvent(event.getId()); // Assumes Event has a method getId()
        if (isDeleted) {
            Toast.makeText(context, "Event deleted: " + event.getTitle(), Toast.LENGTH_SHORT).show();
            eventList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, eventList.size());
        } else {
            Toast.makeText(context, "Failed to delete event: " + event.getTitle(), Toast.LENGTH_SHORT).show();
        }
    }

    // ViewHolder class
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventTitle, eventTime, eventDescription;
        ImageView moreOptions;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.eventTitle);
            eventTime = itemView.findViewById(R.id.eventTime);
            eventDescription = itemView.findViewById(R.id.eventDescription);
            moreOptions = itemView.findViewById(R.id.moreOptions);
        }
    }
}
