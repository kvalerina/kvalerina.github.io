package com.zybooks.projecttwoaronov;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        db = new DatabaseHelper(this);

        EditText oldPasswordInput = findViewById(R.id.oldPasswordInput);
        EditText newPasswordInput = findViewById(R.id.newPasswordInput);
        EditText confirmPasswordInput = findViewById(R.id.confirmPasswordInput);
        Button savePasswordButton = findViewById(R.id.savePasswordButton);

        // Retrieve username from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("LoginPrefs", MODE_PRIVATE);
        String username = prefs.getString("username", ""); // Retrieve the username
        Log.d("ChangePasswordActivity", "Logged-in username: " + username); // Debug log

        if (username.isEmpty()) {
            Toast.makeText(this, "No logged-in user found. Please log in again.", Toast.LENGTH_LONG).show();
            finish(); // Close the activity
            return;
        }

        savePasswordButton.setOnClickListener(v -> {
            String oldPassword = oldPasswordInput.getText().toString().trim();
            String newPassword = newPasswordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();

            if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate old password and update
            if (db.checkUser(username, oldPassword)) {
                int rowsUpdated = db.updateUserPassword(username, newPassword);
                if (rowsUpdated > 0) {
                    Toast.makeText(this, "Password changed successfully!", Toast.LENGTH_LONG).show();
                    finish(); // Close the activity
                } else {
                    Toast.makeText(this, "Failed to update password.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Old password is incorrect.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
