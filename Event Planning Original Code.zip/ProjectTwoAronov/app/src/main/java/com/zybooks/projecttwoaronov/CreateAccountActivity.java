package com.zybooks.projecttwoaronov;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class CreateAccountActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private DatabaseHelper db;
    private String pendingUsername;
    private String pendingPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Initialize the database
        db = new DatabaseHelper(this);

        // UI Components
        EditText usernameInput = findViewById(R.id.usernameInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        EditText confirmPasswordInput = findViewById(R.id.confirmPasswordInput);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Set up button listener
        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();
            String confirmPassword = confirmPasswordInput.getText().toString().trim();

            // Validate fields
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
                Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirmPassword)) {
                Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (password.length() < 6) {
                Toast.makeText(this, "Password must be at least 6 characters long.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if username already exists
            if (db.checkUser(username, "")) { // Check only for the username
                Toast.makeText(this, "Username already exists. Please choose another.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Store the username and password for later use if permissions are required
            pendingUsername = username;
            pendingPassword = password;

            // Check SMS permissions
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                // Request SMS permission
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
            } else {
                // Permission already granted, proceed to create account
                createUserAccount(pendingUsername, pendingPassword);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission granted.", Toast.LENGTH_SHORT).show();
                createUserAccount(pendingUsername, pendingPassword);
            } else {
                Toast.makeText(this, "Permission denied. Proceeding without SMS notifications.", Toast.LENGTH_SHORT).show();
                createUserAccount(pendingUsername, pendingPassword);
            }
        }
    }

    private void createUserAccount(String username, String password) {
        long result = db.addUser(username, password);
        if (result != -1) {
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_LONG).show();
            sendWelcomeSms(username);
            // Navigate to login screen
            Intent intent = new Intent(CreateAccountActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Error creating account. Try again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendWelcomeSms(String username) {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
                String message = "Welcome to Event Planner, " + username + "! Your account has been created successfully and notifications are enabled.";
                String phoneNumber = "+1234567890"; // Fake phone number

                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Log.d("CreateAccountActivity", "SMS sent to: " + phoneNumber);
                Toast.makeText(this, "Welcome SMS sent!", Toast.LENGTH_SHORT).show();
            } else {
                Log.e("CreateAccountActivity", "SMS permission not granted.");
            }
        } catch (Exception e) {
            Log.e("CreateAccountActivity", "Failed to send SMS.", e);
            Toast.makeText(this, "Failed to send SMS. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
