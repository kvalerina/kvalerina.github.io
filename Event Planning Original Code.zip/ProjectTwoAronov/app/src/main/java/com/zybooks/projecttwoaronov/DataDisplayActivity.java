package com.zybooks.projecttwoaronov;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.SearchView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class DataDisplayActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private ArrayList<EventGroup> groupedEventList;
    private GroupedEventAdapter groupedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        db = new DatabaseHelper(this);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        groupedEventList = new ArrayList<>();
        groupedAdapter = new GroupedEventAdapter(groupedEventList);
        recyclerView.setAdapter(groupedAdapter);

        loadData();

        // Navigate to Settings Page
        ImageButton settingsButton = findViewById(R.id.imageButton6);
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        // Set up SearchView
        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterData(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterData(newText);
                return false;
            }
        });

        // Handle add button click
        ImageButton addButton = findViewById(R.id.imageButton5);
        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, AddEventActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData(); // Refresh the event list when returning to this activity
    }

    // Updated loadData method
    private void loadData() {

        HashMap<String, List<Event>> groupedEventsMap = new HashMap<>();
        Cursor cursor = db.getAllEvents();

        if (cursor != null) {
            while (cursor.moveToNext()) {
                try {
                    Event event = new Event(
                            cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID)),
                            cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)),
                            cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE)),
                            cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)),
                            cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESCRIPTION))
                    );

                    // Group events by raw date
                    String eventDate = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE));
                    if (!groupedEventsMap.containsKey(eventDate)) {
                        groupedEventsMap.put(eventDate, new ArrayList<>());
                    }
                    Objects.requireNonNull(groupedEventsMap.get(eventDate)).add(event);

                } catch (Exception e) {
                    Log.e("DataDisplayActivity", "Error reading event data", e);
                }
            }
            cursor.close();
        }

        // Sort groupedEventList by raw dates
        groupedEventList.clear();
        List<String> sortedDates = new ArrayList<>(groupedEventsMap.keySet());

        sortedDates.sort((date1, date2) -> {
            try {
                SimpleDateFormat rawFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                Date parsedDate1 = rawFormat.parse(date1);
                Date parsedDate2 = rawFormat.parse(date2);
                return Objects.requireNonNull(parsedDate1).compareTo(parsedDate2);
            } catch (Exception e) {
                Log.e("DataDisplayActivity", "Error sorting dates", e);
                return 0;
            }
        });

        // Add sorted EventGroups to groupedEventList
        for (String rawDate : sortedDates) {
            String formattedDate = formatDate(rawDate);
            groupedEventList.add(new EventGroup(formattedDate, groupedEventsMap.get(rawDate)));
        }

        groupedAdapter.updateData(new ArrayList<>(groupedEventList));
    }
    private void filterData(String query) {
        query = query.toLowerCase().trim();

        if (query.isEmpty()) {
            loadData();
            return;
        }

        ArrayList<EventGroup> filteredGroups = new ArrayList<>();

        for (EventGroup group : groupedEventList) {
            List<Event> filteredEvents = new ArrayList<>();
            for (Event event : group.getEvents()) {
                if (event.getTitle().toLowerCase().contains(query) ||
                        event.getDescription().toLowerCase().contains(query) ||
                        group.getDate().toLowerCase().contains(query)) {
                    filteredEvents.add(event);
                }
            }
            if (!filteredEvents.isEmpty()) {
                filteredGroups.add(new EventGroup(group.getDate(), filteredEvents));
            }
        }

        groupedAdapter.updateData(filteredGroups);
    }

    private String formatDate(String date) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.getDefault());
            Date parsedDate = inputFormat.parse(date);
            return outputFormat.format(parsedDate);
        } catch (Exception e) {
            Log.e("DataDisplayActivity", "Date parsing error", e);
            return date;
        }
    }
}
