package com.zybooks.projecttwoaronov;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "LoginPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if the user is already logged in
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false);
        if (isLoggedIn) {
            navigateToDataDisplay();
            return;
        }

        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);

        // Initialize UI components
        EditText usernameField = findViewById(R.id.usernameField);
        EditText passwordField = findViewById(R.id.passwordField);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        // Handle login button click
        loginButton.setOnClickListener(v -> {
            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean userExists = db.checkUser(username, password);
            if (userExists) {
                // Save login state in SharedPreferences
                prefs.edit()
                        .putBoolean(KEY_IS_LOGGED_IN, true)
                        .putString("username", username) // Save the logged-in username
                        .apply();

                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                navigateToDataDisplay();
            } else {
                Toast.makeText(this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle create account button click
        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CreateAccountActivity.class);
            startActivity(intent);
        });
    }

    private void navigateToDataDisplay() {
        Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
        startActivity(intent);
        finish(); // Close the login screen
    }
}
