package com.zybooks.projecttwoaronov;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class GroupedEventAdapter extends RecyclerView.Adapter<GroupedEventAdapter.EventGroupViewHolder> {

    private final List<EventGroup> groupedEvents;

    // Constructor
    public GroupedEventAdapter(List<EventGroup> groupedEvents) {
        this.groupedEvents = groupedEvents != null ? groupedEvents : new ArrayList<>();
    }

    @NonNull
    @Override
    public EventGroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.event_group_card, parent, false);
        return new EventGroupViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventGroupViewHolder holder, int position) {
        // Get the current group of events
        EventGroup eventGroup = groupedEvents.get(position);

        // Set the group date
        holder.groupDate.setText(eventGroup.getDate());

        // Set up the nested RecyclerView with EventAdapter
        EventAdapter eventAdapter = new EventAdapter(holder.itemView.getContext(), eventGroup.getEvents());
        holder.nestedRecyclerView.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));
        holder.nestedRecyclerView.setAdapter(eventAdapter);
    }

    @Override
    public int getItemCount() {
        return groupedEvents.size();
    }

    // Method to update the data dynamically (existing version)
    public void updateData(List<EventGroup> newGroups) {
        groupedEvents.clear();
        groupedEvents.addAll(newGroups);
        notifyDataSetChanged();
    }

    // Method to update data with ArrayList specifically (new method)
    public void updateData(ArrayList<EventGroup> newData) {
        this.groupedEvents.clear();
        this.groupedEvents.addAll(newData);
        notifyDataSetChanged();
    }

    // ViewHolder for grouped events
    public static class EventGroupViewHolder extends RecyclerView.ViewHolder {
        TextView groupDate;
        RecyclerView nestedRecyclerView;

        public EventGroupViewHolder(@NonNull View itemView) {
            super(itemView);

            // Find the views from the layout
            groupDate = itemView.findViewById(R.id.groupDate); // Ensure your event_group_card.xml has this ID
            nestedRecyclerView = itemView.findViewById(R.id.nestedRecyclerView); // Ensure this ID matches
        }
    }
}
