package com.zybooks.projecttwoaronov

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SmsNotificationActivity : AppCompatActivity() {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private lateinit var permissionMessage: TextView
    private lateinit var grantPermissionButton: Button
    private lateinit var skipPermissionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_notification)

        // Initialize UI elements
        permissionMessage = findViewById(R.id.permissionMessage)
        grantPermissionButton = findViewById(R.id.grantPermissionButton)
        skipPermissionButton = findViewById(R.id.skipPermissionButton)

        // Get the logged-in user
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "No logged-in user found!", Toast.LENGTH_LONG).show()
            goToMainApp()
            return
        }

        // Handle "Grant Permission" button click
        grantPermissionButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
            ) {
                // Permission already granted
                permissionMessage.text = getString(R.string.permission_already_granted)
                Toast.makeText(this, "SMS Permission Already Granted", Toast.LENGTH_SHORT).show()
                updateSmsPreference(currentUser.uid, true) // Save preference in Firestore
            } else {
                // Request permission
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.SEND_SMS),
                    SMS_PERMISSION_REQUEST_CODE
                )
            }
        }

        // Skip permission and continue using the app
        skipPermissionButton.setOnClickListener {
            updateSmsPreference(currentUser.uid, false) // Save preference as disabled
            Toast.makeText(this, "SMS permissions denied. You can enable it in Settings.", Toast.LENGTH_LONG).show()
            goToMainApp()
        }
    }

    // Handle permission request results
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        val currentUser = auth.currentUser
        if (currentUser == null) {
            goToMainApp()
            return
        }

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionMessage.text = getString(R.string.permission_granted)
                Toast.makeText(this, "Permission granted. SMS notifications enabled.", Toast.LENGTH_SHORT).show()
                updateSmsPreference(currentUser.uid, true) // Enable SMS in Firestore
            } else {
                permissionMessage.text = getString(R.string.permission_denied)
                Toast.makeText(this, "Permission denied. The app will function without SMS.", Toast.LENGTH_LONG).show()
                updateSmsPreference(currentUser.uid, false) // Disable SMS in Firestore
            }
            goToMainApp()
        }
    }

    // Update SMS preference in Firestore
    private fun updateSmsPreference(userId: String, isEnabled: Boolean) {
        db.collection("users").document(userId)
            .update("smsEnabled", isEnabled)
            .addOnSuccessListener {
                val message = if (isEnabled) "SMS Notifications Enabled" else "SMS Notifications Disabled"
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update settings in Firestore.", Toast.LENGTH_SHORT).show()
            }
    }

    // Navigate back to the main app
    private fun goToMainApp() {
        val intent = Intent(this@SmsNotificationActivity, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    companion object {
        private const val SMS_PERMISSION_REQUEST_CODE = 100
    }
}
