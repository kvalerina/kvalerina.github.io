package com.zybooks.projecttwoaronov

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth

class CreateAccountActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_account)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // UI Components
        val usernameInput = findViewById<EditText>(R.id.usernameInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val confirmPasswordInput = findViewById<EditText>(R.id.confirmPasswordInput)
        val createAccountButton = findViewById<Button>(R.id.createAccountButton)

        // Set up button listener
        createAccountButton.setOnClickListener {
            val email = usernameInput.text.toString().trim() // Firebase Auth uses email as username
            val password = passwordInput.text.toString().trim()
            val confirmPassword = confirmPasswordInput.text.toString().trim()

            if (!validateLoginInput(email, password, confirmPassword)) return@setOnClickListener

            createUserAccount(email, password)
        }
    }

    // Validate username and password input
    private fun validateLoginInput(email: String, password: String, confirmPassword: String): Boolean {
        if (email.isBlank() || password.isBlank() || confirmPassword.isBlank()) {
            showSnackbar("All fields are required.")
            return false
        }

        if (password != confirmPassword) {
            showSnackbar("Passwords do not match.")
            return false
        }

        val passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}$"
        if (!password.matches(Regex(passwordPattern))) {
            showSnackbar("Password must be at least 8 characters, including 1 uppercase, 1 lowercase, 1 number, and 1 special character.")
            return false
        }

        return true
    }

    // Create a new user account using Firebase Authentication
    private fun createUserAccount(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    showSnackbar("Account created successfully!")

                    // Redirect to main screen
                    val intent = Intent(this@CreateAccountActivity, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish()
                } else {
                    showSnackbar("Error: ${task.exception?.message}")
                    Log.e("CreateAccountActivity", "Account creation failed", task.exception)
                }
            }
    }

    // Utility function to show a Snackbar message
    private fun showSnackbar(message: String) {
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG).show()
    }
}
