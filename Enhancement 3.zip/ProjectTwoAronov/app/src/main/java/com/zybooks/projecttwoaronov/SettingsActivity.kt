package com.zybooks.projecttwoaronov

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SettingsActivity : AppCompatActivity() {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private lateinit var usernameText: TextView
    private lateinit var smsToggle: SwitchCompat
    private lateinit var changePasswordButton: Button
    private lateinit var logoutButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Initialize UI components
        usernameText = findViewById(R.id.usernameText)
        smsToggle = findViewById(R.id.smsToggle)
        changePasswordButton = findViewById(R.id.changePasswordButton)
        logoutButton = findViewById(R.id.logoutButton)

        val homeButton = findViewById<ImageButton>(R.id.imageButton4)
        val addButton = findViewById<ImageButton>(R.id.imageButton5)

        // Load current user info
        val currentUser = auth.currentUser
        if (currentUser != null) {
            usernameText.text = getString(R.string.username_display, currentUser.email ?: "Unknown User")
            loadUserSettings(currentUser.uid)
        } else {
            Toast.makeText(this, "No logged-in user found!", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // SMS Toggle Listener
        smsToggle.setOnCheckedChangeListener { _, isChecked ->
            updateSmsPreference(currentUser.uid, isChecked)
            if (isChecked) requestSmsPermission()
        }

        // Change Password Button
        changePasswordButton.setOnClickListener {
            startActivity(Intent(this, ChangePasswordActivity::class.java))
        }

        // Logout Button
        logoutButton.setOnClickListener {
            showLogoutConfirmation()
        }

        // Navigation Buttons
        homeButton.setOnClickListener {
            val intent = Intent(this, DataDisplayActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }

        addButton.setOnClickListener {
            startActivity(Intent(this, AddEventActivity::class.java))
        }

        findViewById<View>(R.id.imageButton7).setOnClickListener {
            startActivity(Intent(this, MonthlyViewActivity::class.java))
        }
    }

    // Load user settings from Firestore
    private fun loadUserSettings(userId: String) {
        db.collection("users").document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val isSmsEnabled = document.getBoolean("smsEnabled") ?: false
                    smsToggle.isChecked = isSmsEnabled
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to load settings", Toast.LENGTH_SHORT).show()
            }
    }

    // Update SMS preference in Firestore
    private fun updateSmsPreference(userId: String, isEnabled: Boolean) {
        db.collection("users").document(userId)
            .update("smsEnabled", isEnabled)
            .addOnSuccessListener {
                val message = if (isEnabled) "SMS Notifications Enabled" else "SMS Notifications Disabled"
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to update settings", Toast.LENGTH_SHORT).show()
            }
    }

    // Show logout confirmation dialog
    private fun showLogoutConfirmation() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Log Out")
        builder.setMessage("Are you sure you want to log out?")

        builder.setPositiveButton("Log Out") { _, _ ->
            performLogout()
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

    // Logout function
    private fun performLogout() {
        auth.signOut() // Firebase logout

        // Restart app from MainActivity
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)

        finishAffinity() // Close all activities
        Toast.makeText(this, "Logged out successfully.", Toast.LENGTH_SHORT).show()
    }

    // Request SMS permission
    private fun requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_REQUEST_CODE
            )
        } else {
            sendSmsNotification()
        }
    }

    // Send SMS Notification
    private fun sendSmsNotification() {
        try {
            val smsManager = SmsManager.getDefault()
            val phoneNumber = "+1234567890"
            smsManager.sendTextMessage(phoneNumber, null, "SMS notifications enabled!", null, null)
            Toast.makeText(this, "Notification sent via SMS!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send SMS notification.", Toast.LENGTH_SHORT).show()
        }
    }

    // Handle SMS permission request result
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsNotification()
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val SMS_PERMISSION_REQUEST_CODE = 100
    }
}
