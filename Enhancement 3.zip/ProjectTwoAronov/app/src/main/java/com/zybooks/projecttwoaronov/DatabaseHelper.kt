package com.zybooks.projecttwoaronov

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore

class DatabaseHelper {
    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    // Reference to the events collection
    private val eventsCollection = db.collection("events")

    // Add a new event
    fun addEvent(
        eventName: String,
        eventDate: String,
        eventTime: String,
        eventDescription: String,
        eventPriority: String,
        callback: (Boolean) -> Unit
    ) {
        val userId = auth.currentUser?.uid ?: return callback(false)

        // Use the correct field names in Firestore
        val event = hashMapOf(
            "userId" to userId,
            "eventName" to eventName,
            "eventDate" to eventDate,  // Updated field name
            "eventTime" to eventTime,  // Updated field name
            "eventDescription" to eventDescription,  // Updated field name
            "eventPriority" to eventPriority,  // Updated field name
            "eventId" to ""
        )

        eventsCollection.add(event)
            .addOnSuccessListener {
                Log.d("DatabaseHelper", "Event added successfully!")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.e("DatabaseHelper", "Error adding event", e)
                callback(false)
            }
    }

    // Delete an event
    fun deleteEvent(eventId: String, callback: (Boolean) -> Unit) {
        eventsCollection.document(eventId).delete()
            .addOnSuccessListener {
                Log.d("DatabaseHelper", "Event deleted successfully!")
                callback(true)
            }
            .addOnFailureListener { e ->
                Log.e("DatabaseHelper", "Error deleting event", e)
                callback(false)
            }
    }

    // Get all events for the logged-in user
    fun getUserEvents(callback: (List<DocumentSnapshot>) -> Unit) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        db.collection("events")
            .whereEqualTo("userId", userId) // Filter events by userId
            .get()
            .addOnSuccessListener { result ->
                callback(result.documents) // Return list of QueryDocumentSnapshots
            }
            .addOnFailureListener { e ->
                Log.e("DatabaseHelper", "Error getting events", e)
                callback(emptyList())
            }
    }
}
