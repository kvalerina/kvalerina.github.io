package com.zybooks.projecttwoaronov

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AutoCompleteTextView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class DataDisplayActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private val db = FirebaseFirestore.getInstance()  // Initialize Firestore
    private val eventList = mutableListOf<Event>()
    private lateinit var eventAdapter: EventAdapter
    private lateinit var searchDropdown: AutoCompleteTextView
    private lateinit var noEventsTextView: TextView
    private lateinit var greetingTextView: TextView
    private lateinit var dateTextView: TextView // Reference to the date TextView

    private var currentSortOption: SortOption = SortOption.TIME_ASC

    private enum class SortOption {
        TIME_ASC, PRIORITY_ASC
    }

    private fun listenForEventUpdates() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        db.collection("events")
            .whereEqualTo("userId", userId)  // Filter events by userId
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    Log.e("DataDisplayActivity", "Error fetching events", exception)
                    return@addSnapshotListener
                }

                snapshot?.let {
                    eventList.clear()
                    it.documents.forEach { document ->
                        eventList.add(
                            Event(
                                id = document.id,  // Firestore document ID
                                title = document.getString("eventName") ?: "",
                                date = document.getString("eventDate") ?: "",
                                time = document.getString("eventTime") ?: "",
                                description = document.getString("eventDescription") ?: "",
                                priority = document.getString("eventPriority") ?: ""
                            )
                        )
                    }

                    eventAdapter.notifyDataSetChanged() // Notify the adapter to refresh the list
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_view)

        dbHelper = DatabaseHelper()

        searchDropdown = findViewById(R.id.searchDropdown)
        noEventsTextView = findViewById(R.id.noEventsTextView)
        greetingTextView = findViewById(R.id.greetingTextView)
        dateTextView = findViewById(R.id.dateTextView)

        displayTodayDate()

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        eventAdapter = EventAdapter(this, eventList) { event ->
            deleteEvent(event)
        }
        recyclerView.adapter = eventAdapter

        loadUserEvents()

        listenForEventUpdates()  // Listen for real-time changes

        greetingTextView.text = getGreetingMessage()

        searchDropdown.setOnItemClickListener { _, _, position, _ ->
            val selectedEvent = eventList[position]
            openEditEventScreen(selectedEvent.id)
        }

        findViewById<View>(R.id.sortButton).setOnClickListener { view ->
            showSortMenu(view)
        }

        findViewById<View>(R.id.imageButton7).setOnClickListener {
            startActivity(Intent(this, MonthlyViewActivity::class.java))
        }
        findViewById<View>(R.id.imageButton5).setOnClickListener {
            startActivity(Intent(this, AddEventActivity::class.java))
        }
        findViewById<View>(R.id.imageButton6).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun displayTodayDate() {
        val currentDate = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault()).format(Date())
        dateTextView.text = currentDate
    }

    private fun loadUserEvents() {
        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        dbHelper.getUserEvents { events ->
            eventList.clear()

            events.forEach { document ->
                Log.d("MonthlyViewActivity", "Event date in Firestore: ${document.getString("eventDate")}")
            }

            val filteredEvents = events.filter { document ->
                document.getString("userId") == userId && document.getString("eventDate") == currentDate
            }

            eventList.addAll(filteredEvents.map { document ->
                Event(
                    id = document.id,
                    title = document.getString("eventName") ?: "",
                    date = document.getString("eventDate") ?: "",
                    time = document.getString("eventTime") ?: "",
                    description = document.getString("eventDescription") ?: "",
                    priority = document.getString("eventPriority") ?: ""
                )
            })

            sortAndDisplayEvents()
        }
    }

    private fun deleteEvent(event: Event) {
        dbHelper.deleteEvent(event.id) { success ->
            if (success) {
                Log.d("DataDisplayActivity", "Event deleted successfully")
                loadUserEvents() // Refresh list after deleting
            } else {
                Log.e("DataDisplayActivity", "Error deleting event")
            }
        }
    }

    private fun openEditEventScreen(eventId: String) {
        val selectedEvent = eventList.find { it.id == eventId }

        selectedEvent?.let {
            val intent = Intent(this, EditEventActivity::class.java)
            intent.putExtra("EVENT_ID", eventId)
            startActivity(intent)
        } ?: run {
            Log.e("DataDisplayActivity", "Event not found")
        }
    }

    private fun showSortMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.sort_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.sort_time -> currentSortOption = SortOption.TIME_ASC
                R.id.sort_priority -> currentSortOption = SortOption.PRIORITY_ASC
            }
            sortAndDisplayEvents()
            true
        }
        popupMenu.show()
    }

    private fun sortAndDisplayEvents() {
        when (currentSortOption) {
            SortOption.TIME_ASC -> eventList.sortBy { it.time }
            SortOption.PRIORITY_ASC -> eventList.sortBy { it.priority }
        }

        eventAdapter.notifyDataSetChanged()

        noEventsTextView.visibility = if (eventList.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun getGreetingMessage(): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 5..11 -> "Good morning!"
            in 12..17 -> "Good afternoon!"
            else -> "Good evening!"
        }
    }
}
