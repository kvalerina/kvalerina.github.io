package com.zybooks.projecttwoaronov

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class MonthlyViewActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper

    private val eventList = mutableListOf<Event>()
    private lateinit var eventAdapter: EventAdapter
    private lateinit var selectedDateTextView: TextView
    private lateinit var noEventsTextView: TextView
    private lateinit var searchDropdown: AutoCompleteTextView

    private var selectedDate: String = ""
    private var currentSortOption: SortOption = SortOption.TIME_ASC

    private val db = FirebaseFirestore.getInstance()

    // Enum for sorting options
    private enum class SortOption {
        TIME_ASC, PRIORITY_ASC
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monthly_view)

        // Initialize DatabaseHelper
        dbHelper = DatabaseHelper()

        // Initialize UI components
        searchDropdown = findViewById(R.id.searchDropdown)
        selectedDateTextView = findViewById(R.id.selectedDateTextView)
        noEventsTextView = findViewById(R.id.noEventsTextView)

        // Set up RecyclerView for event list
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        eventAdapter = EventAdapter(this, eventList) { event ->
            deleteEvent(event) // Delete event using DatabaseHelper
        }
        recyclerView.adapter = eventAdapter

        // Set up CalendarView to select dates
        val calendarView = findViewById<CalendarView>(R.id.calendarView)
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            selectedDateTextView.text = formatDate(selectedDate)
            loadEventsForDate(selectedDate) // Load events for selected date
        }

        // Load all events for search
        loadAllEventsForSearch()

        // Handle dropdown search selection
        searchDropdown.setOnItemClickListener { _, _, position, _ ->
            val selectedEvent = eventList[position]
            openEditEventScreen(selectedEvent.id)
        }

        // Sorting button listener
        findViewById<View>(R.id.sortButton).setOnClickListener { view ->
            showSortMenu(view)
        }

        // Load current month by default
        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        selectedDate = currentDate
        selectedDateTextView.text = formatDate(currentDate)
        loadEventsForDate(selectedDate)

        // Footer Button Listeners
        findViewById<View>(R.id.imageButton4).setOnClickListener {
            startActivity(Intent(this, DataDisplayActivity::class.java))
        }
        findViewById<View>(R.id.imageButton7).setOnClickListener {
            startActivity(Intent(this, MonthlyViewActivity::class.java))
        } // Refresh Monthly View
        findViewById<View>(R.id.imageButton5).setOnClickListener {
            startActivity(Intent(this, AddEventActivity::class.java))
        }
        findViewById<View>(R.id.imageButton6).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // Listen to real-time updates
        listenForEventUpdates()
    }

    // Function to listen for real-time updates
    private fun listenForEventUpdates() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        db.collection("events")
            .whereEqualTo("userId", userId)  // Filter events by userId
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    Log.e("MonthlyViewActivity", "Error fetching events", exception)
                    return@addSnapshotListener
                }

                snapshot?.let {
                    eventList.clear()  // Clear current list of events
                    it.documents.forEach { document ->
                        eventList.add(
                            Event(
                                id = document.id,  // Firestore document ID
                                title = document.getString("eventName") ?: "",
                                date = document.getString("eventDate") ?: "",
                                time = document.getString("eventTime") ?: "",
                                description = document.getString("eventDescription") ?: "",
                                priority = document.getString("eventPriority") ?: ""
                            )
                        )
                    }

                    eventAdapter.notifyDataSetChanged() // Notify the adapter to refresh the list
                }
            }
    }

    // Load events for the selected date from DatabaseHelper
    private fun loadEventsForDate(date: String) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        Log.d("MonthlyViewActivity", "Current date: $date") // Use the passed date here
        Log.d("MonthlyViewActivity", "Current user ID: $userId")
        Log.d("MonthlyViewActivity", "Querying DatabaseHelper for date: $date")

        dbHelper.getUserEvents { events ->

            eventList.clear()  // Clear event list before updating it

            // Log event data for debugging
            events.forEach { event ->
                Log.d("MonthlyViewActivity", "Event date in Firestore: ${event["eventDate"]}")
            }

            // Explicitly define the lambda parameter as 'event' to filter by userId and eventDate
            val filteredEvents = events.filter { event ->
                event["userId"] == userId && event["eventDate"] == date
            }

            // Convert filtered events to Event objects
            eventList.addAll(filteredEvents.map { event ->
                Event(
                    id = event.id,
                    title = event.getString("eventName") ?: "",
                    date = event.getString("eventDate") ?: "",
                    time = event.getString("eventTime") ?: "",
                    description = event.getString("eventDescription") ?: "",
                    priority = event.getString("eventPriority") ?: ""
                )
            })

            // Sort and display events
            sortAndDisplayEvents()

            // Log the number of filtered events for debugging
            Log.d("MonthlyViewActivity", "Filtered events: ${filteredEvents.size}")
        }
    }

    // Load all events for search functionality
    private fun loadAllEventsForSearch() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        dbHelper.getUserEvents { events ->

            val allEventsList = events.map { event ->
                Event(
                    id = event.id,
                    title = event.getString("eventName") ?: "",
                    date = event.getString("eventDate") ?: "",
                    time = event.getString("eventTime") ?: "",
                    description = event.getString("eventDescription") ?: "",
                    priority = event.getString("eventPriority") ?: ""
                )
            }

            val eventNames = allEventsList.map { "${it.title} - ${it.date} at ${it.time}" }
            val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, eventNames)
            searchDropdown.setAdapter(adapter)
        }
    }

    // Delete event using DatabaseHelper
    private fun deleteEvent(event: Event) {
        dbHelper.deleteEvent(event.id) { success ->
            if (success) {
                Log.d("MonthlyViewActivity", "Event deleted successfully")
                loadEventsForDate(selectedDate) // Refresh list after deletion
            } else {
                Log.e("MonthlyViewActivity", "Error deleting event")
            }
        }
    }

    // Show sorting menu
    private fun showSortMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.sort_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.sort_time -> currentSortOption = SortOption.TIME_ASC
                R.id.sort_priority -> currentSortOption = SortOption.PRIORITY_ASC
            }
            sortAndDisplayEvents()
            true
        }
        popupMenu.show()
    }

    // Sort and display events
    private fun sortAndDisplayEvents() {
        when (currentSortOption) {
            SortOption.TIME_ASC -> eventList.sortBy { it.time }
            SortOption.PRIORITY_ASC -> eventList.sortBy { it.priority }
        }

        eventAdapter.notifyDataSetChanged()

        // Show or hide "No Events Scheduled" message
        noEventsTextView.visibility = if (eventList.isEmpty()) View.VISIBLE else View.GONE
    }

    // Function to open edit event screen
    private fun openEditEventScreen(eventId: String) {
        // Find the event by id from the eventList
        val selectedEvent = eventList.find { it.id == eventId }

        // If the event is found, pass the event ID to the next activity
        selectedEvent?.let {
            val intent = Intent(this, EditEventActivity::class.java)
            intent.putExtra("EVENT_ID", eventId)  // Pass the event ID to the EditEventActivity
            startActivity(intent)
        } ?: run {
            // Handle the case if no event is found
            Log.e("MonthlyViewActivity", "Event with ID $eventId not found")
        }
    }

    // Function to format date properly
    private fun formatDate(date: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val outputFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
            val parsedDate = inputFormat.parse(date)
            parsedDate?.let { outputFormat.format(it) } ?: date
        } catch (e: Exception) {
            Log.e("MonthlyViewActivity", "Date parsing error", e)
            date
        }
    }
}
