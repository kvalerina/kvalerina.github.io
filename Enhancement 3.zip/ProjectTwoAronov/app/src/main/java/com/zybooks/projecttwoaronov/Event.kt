package com.zybooks.projecttwoaronov

data class Event(
    val id: String,
    val title: String,
    val date: String,
    val time: String,
    val description: String,
    val priority: String
)
