package com.zybooks.projecttwoaronov

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Calendar
import java.util.Locale

class EditEventActivity : AppCompatActivity() {
    private val db = FirebaseFirestore.getInstance()

    private var eventId: String? = null  // Firestore document ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_event)

        // Hook up UI elements
        val eventNameInput = findViewById<EditText>(R.id.eventNameInput)
        val eventDateInput = findViewById<EditText>(R.id.eventDateInput)
        val eventTimeInput = findViewById<EditText>(R.id.eventTimeInput)
        val eventDescriptionInput = findViewById<EditText>(R.id.eventDescriptionInput)
        val eventPrioritySpinner = findViewById<Spinner>(R.id.eventPrioritySpinner)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val cancelButton = findViewById<Button>(R.id.cancelButton)

        // Get Event ID from Intent
        eventId = intent.getStringExtra("EVENT_ID")
        Log.d("EditEventActivity", "Received Event ID: $eventId")

        if (eventId.isNullOrEmpty()) {
            Toast.makeText(this, "Error: Invalid Event ID", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Load event data from Firestore
        loadEventData(eventId!!, eventNameInput, eventDateInput, eventTimeInput, eventDescriptionInput, eventPrioritySpinner)

        // Date Picker
        eventDateInput.setOnClickListener {
            showDatePicker(eventDateInput)
        }

        // Time Picker
        eventTimeInput.setOnClickListener {
            showTimePicker(eventTimeInput)
        }

        // Save Button
        saveButton.setOnClickListener {
            val updatedName = eventNameInput.text.toString().trim()
            val updatedDate = eventDateInput.text.toString().trim()
            val updatedTime = eventTimeInput.text.toString().trim()
            val updatedDescription = eventDescriptionInput.text.toString().trim()
            val updatedPriority = eventPrioritySpinner.selectedItem.toString()

            if (updatedName.isEmpty() || updatedDate.isEmpty() || updatedTime.isEmpty()) {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            updateEvent(eventId!!, updatedName, updatedDate, updatedTime, updatedDescription, updatedPriority)
            val intent = Intent(this, DataDisplayActivity::class.java)
            startActivity(intent) // Restart or navigate back to the event list
        }

        // Cancel Button
        cancelButton.setOnClickListener {
            finish()
        }
    }

    // Load Event Data from Firestore
    private fun loadEventData(eventId: String, eventNameInput: EditText, eventDateInput: EditText, eventTimeInput: EditText, eventDescriptionInput: EditText, eventPrioritySpinner: Spinner) {
        db.collection("events").document(eventId)  // Firestore document ID
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    eventNameInput.setText(document.getString("eventName"))
                    eventDateInput.setText(document.getString("eventDate"))
                    eventTimeInput.setText(document.getString("eventTime"))
                    eventDescriptionInput.setText(document.getString("eventDescription"))

                    // Set Priority Spinner
                    val eventPriority = document.getString("eventPriority") ?: "Medium"
                    val priorities = resources.getStringArray(R.array.event_priorities)
                    val priorityIndex = priorities.indexOf(eventPriority)
                    if (priorityIndex >= 0) {
                        eventPrioritySpinner.setSelection(priorityIndex)
                    }
                } else {
                    Toast.makeText(this, "Error: Event not found", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
            .addOnFailureListener { e ->
                Log.e("EditEventActivity", "Error loading event data", e)
                Toast.makeText(this, "Failed to load event", Toast.LENGTH_LONG).show()
                finish()
            }
    }


    // Update Event in Firestore
    private fun updateEvent(eventId: String, name: String, date: String, time: String, description: String, priority: String) {
        val eventUpdates = mapOf(
            "eventName" to name,
            "eventDate" to date,
            "eventTime" to time,
            "eventDescription" to description,
            "eventPriority" to priority
        )

        db.collection("events").document(eventId)
            .update(eventUpdates)
            .addOnSuccessListener {
                Toast.makeText(this, "Event updated successfully!", Toast.LENGTH_SHORT).show()
                finish()
            }
            .addOnFailureListener { e ->
                Log.e("EditEventActivity", "Error updating event", e)
                Toast.makeText(this, "Failed to update event", Toast.LENGTH_SHORT).show()
            }
    }

    // Show Date Picker
    private fun showDatePicker(eventDateInput: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = String.format(Locale.US, "%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay)
            eventDateInput.setText(formattedDate)
        }, year, month, day).show()
    }

    // Show Time Picker
    private fun showTimePicker(eventTimeInput: EditText) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            val amPm = if (selectedHour < 12) "AM" else "PM"
            val formattedHour = if (selectedHour % 12 == 0) 12 else selectedHour % 12
            val formattedTime = String.format(Locale.US, "%02d:%02d %s", formattedHour, selectedMinute, amPm)

            eventTimeInput.setText(formattedTime)
        }, hour, minute, false).show()
    }
}
