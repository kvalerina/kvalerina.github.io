package com.zybooks.projecttwoaronov

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Initialize UI components
        val usernameText = findViewById<TextView>(R.id.usernameText)
        val smsToggle = findViewById<SwitchCompat>(R.id.smsToggle) // Use SwitchCompat
        val changePasswordButton = findViewById<Button>(R.id.changePasswordButton)
        val logoutButton = findViewById<Button>(R.id.logoutButton)
        val homeButton = findViewById<ImageButton>(R.id.imageButton4) // Home button
        val addButton = findViewById<ImageButton>(R.id.imageButton5) // Add button

        // Load saved username
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val encryptedPrefs = EncryptedSharedPreferences.create(
            this,
            "EncryptedLoginPrefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        val username = encryptedPrefs.getString("username", "Unknown User")!!
        usernameText.text = getString(R.string.username_display, username)

        // Load saved SMS toggle state
        val sharedPreferences = getSharedPreferences("SettingsPreferences", MODE_PRIVATE)
        val isSmsEnabled = sharedPreferences.getBoolean("smsEnabled", false)
        smsToggle.isChecked = isSmsEnabled

        // Set SMS Toggle functionality
        smsToggle.setOnCheckedChangeListener { _, isChecked ->
            val editor = sharedPreferences.edit()
            editor.putBoolean("smsEnabled", isChecked)
            editor.apply()
            if (isChecked) {
                requestSmsPermission()
            } else {
                Toast.makeText(this, "SMS Notifications Disabled", Toast.LENGTH_SHORT).show()
            }
        }

        // Set Change Password button functionality
        changePasswordButton.setOnClickListener {
            val intent = Intent(this, ChangePasswordActivity::class.java)
            startActivity(intent)
        }

        // Log Out Button Click Listener
        logoutButton.setOnClickListener {
            showLogoutConfirmation()
        }

        // Home Button Click Listener
        homeButton.setOnClickListener {
            val intent = Intent(this, DailyViewActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
        }

        // Add Button Click Listener
        addButton.setOnClickListener {
            val intent = Intent(this, AddEventActivity::class.java)
            startActivity(intent)
        }

        // Add Monthly View Click Listener
        findViewById<View>(R.id.imageButton7).setOnClickListener {
            startActivity(Intent(this, MonthlyViewActivity::class.java))
        }
    }

    // Function to show logout confirmation dialog
    private fun showLogoutConfirmation() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Log Out")
        builder.setMessage("Are you sure you want to log out?")

        builder.setPositiveButton("Log Out") { _, _ ->
            performLogout()
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }

        builder.show()
    }

    // Function to handle actual logout
    private fun performLogout() {
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val encryptedPrefs = EncryptedSharedPreferences.create(
            this,
            "EncryptedLoginPrefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        // Clear encrypted preferences
        encryptedPrefs.edit()
            .remove("isLoggedIn")
            .remove("username")
            .apply()

        // Restart app from MainActivity
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)

        finishAffinity() // Close all activities

        Toast.makeText(this, "Logged out successfully.", Toast.LENGTH_SHORT).show()
    }

    // Request SMS permission
    private fun requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION_REQUEST_CODE
            )
        } else {
            sendSmsNotification()
        }
    }

    // Send SMS Notification
    private fun sendSmsNotification() {
        try {
            val smsManager = SmsManager.getDefault()
            val phoneNumber = "+1234567890"
            smsManager.sendTextMessage(phoneNumber, null, "SMS notifications enabled!", null, null)
            Toast.makeText(this, "Notification sent via SMS!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send SMS notification.", Toast.LENGTH_SHORT).show()
        }
    }

    // Handle the result of the permission request
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show()
                sendSmsNotification()
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        private const val SMS_PERMISSION_REQUEST_CODE = 100
    }
}
