package com.zybooks.projecttwoaronov

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Base64
import android.util.Log
import java.security.MessageDigest

class DatabaseHelper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        try {
            // Create Users Table
            db.execSQL(
                """
                CREATE TABLE $TABLE_USERS (
                    $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_USERNAME TEXT UNIQUE,
                    $COLUMN_PASSWORD TEXT
                )
                """.trimIndent()
            )

            // Create Events Table
            db.execSQL(
                """
                CREATE TABLE $TABLE_EVENTS (
                    $COLUMN_EVENT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_EVENT_NAME TEXT,
                    $COLUMN_EVENT_DATE TEXT,
                    $COLUMN_EVENT_TIME TEXT,
                    $COLUMN_EVENT_DESCRIPTION TEXT,
                    $COLUMN_EVENT_PRIORITY TEXT DEFAULT 'Medium'
                )
                """.trimIndent()
            )
            Log.d("DatabaseHelper", "Tables created successfully")
        } catch (e: Exception) {
            logError("onCreate", e)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        try {
            if (oldVersion < 2) {
                db.execSQL("ALTER TABLE $TABLE_EVENTS ADD COLUMN $COLUMN_EVENT_PRIORITY TEXT DEFAULT 'Medium'")
            }
            Log.d("DatabaseHelper", "Database upgraded successfully")
        } catch (e: Exception) {
            logError("onUpgrade", e)
        }
    }

    // Add an event
    fun addEvent(eventName: String, eventDate: String, eventTime: String, eventDescription: String, eventPriority: String): Long {
        val values = ContentValues().apply {
            put(COLUMN_EVENT_NAME, eventName)
            put(COLUMN_EVENT_DATE, eventDate)
            put(COLUMN_EVENT_TIME, eventTime)
            put(COLUMN_EVENT_DESCRIPTION, eventDescription)
            put(COLUMN_EVENT_PRIORITY, eventPriority)
        }
        return try {
            writableDatabase.insert(TABLE_EVENTS, null, values)
        } catch (e: Exception) {
            logError("addEvent", e)
            -1L
        }
    }

    // Update an event
    fun updateEvent(eventId: Int, eventName: String, eventDate: String, eventTime: String, eventDescription: String, eventPriority: String): Int {
        val values = ContentValues().apply {
            put(COLUMN_EVENT_NAME, eventName)
            put(COLUMN_EVENT_DATE, eventDate)
            put(COLUMN_EVENT_TIME, eventTime)
            put(COLUMN_EVENT_DESCRIPTION, eventDescription)
            put(COLUMN_EVENT_PRIORITY, eventPriority)
        }
        return try {
            writableDatabase.update(TABLE_EVENTS, values, "$COLUMN_EVENT_ID = ?", arrayOf(eventId.toString()))
        } catch (e: Exception) {
            logError("updateEvent", e)
            -1
        }
    }

    // Delete an event
    fun deleteEvent(eventId: Int): Boolean {
        return try {
            writableDatabase.delete(TABLE_EVENTS, "$COLUMN_EVENT_ID = ?", arrayOf(eventId.toString())) > 0
        } catch (e: Exception) {
            logError("deleteEvent", e)
            false
        }
    }

    // Get an event by ID
    fun getEventById(eventId: Int): Cursor? {
        return try {
            val cursor = readableDatabase.rawQuery("SELECT * FROM $TABLE_EVENTS WHERE $COLUMN_EVENT_ID = ?", arrayOf(eventId.toString()))
            if (cursor.count == 0) {
                cursor.close()
                null
            } else cursor
        } catch (e: Exception) {
            logError("getEventById", e)
            null
        }
    }

    // Get all events
    val allEvents: Cursor?
        get() = try {
            readableDatabase.rawQuery("SELECT * FROM $TABLE_EVENTS", null)
        } catch (e: Exception) {
            logError("getAllEvents", e)
            null
        }

    // Add a new user
    fun addUser(username: String, password: String): Long {
        val hashedPassword = hashPassword(password)
        return if (hashedPassword != null) {
            val values = ContentValues().apply {
                put(COLUMN_USERNAME, username)
                put(COLUMN_PASSWORD, hashedPassword)
            }
            try {
                writableDatabase.insert(TABLE_USERS, null, values)
            } catch (e: Exception) {
                logError("addUser", e)
                -1L
            }
        } else {
            -1L
        }
    }

    // Check if a user exists
    fun checkUser(username: String, password: String?): Boolean {
        return try {
            val query: String
            val args: Array<String>

            if (password.isNullOrEmpty()) {
                query = "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME = ?"
                args = arrayOf(username.trim())
            } else {
                val hashedPassword = hashPassword(password) ?: return false
                query = "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
                args = arrayOf(username.trim(), hashedPassword)
            }

            readableDatabase.rawQuery(query, args).use { cursor ->
                cursor.count > 0
            }
        } catch (e: Exception) {
            logError("checkUser", e)
            false
        }
    }

    // Update user password
    fun updateUserPassword(username: String, newPassword: String): Int {
        val hashedPassword = hashPassword(newPassword)
        return if (hashedPassword != null) {
            val values = ContentValues().apply {
                put(COLUMN_PASSWORD, hashedPassword)
            }
            try {
                writableDatabase.update(TABLE_USERS, values, "$COLUMN_USERNAME = ?", arrayOf(username.trim()))
            } catch (e: Exception) {
                logError("updateUserPassword", e)
                -1
            }
        } else {
            -1
        }
    }

    // Hash a password using SHA-256
    private fun hashPassword(password: String): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(password.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(hash, Base64.DEFAULT).trim()
        } catch (e: Exception) {
            logError("hashPassword", e)
            null
        }
    }

    // Log errors for debugging
    private fun logError(method: String, e: Exception) {
        Log.e("DatabaseHelper", "Error in $method: ${e.message}", e)
    }

    companion object {
        private const val DATABASE_NAME = "EventPlanner.db"
        private const val DATABASE_VERSION = 2

        // Users Table
        const val TABLE_USERS = "users"
        const val COLUMN_USER_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"

        // Events Table
        const val TABLE_EVENTS = "events"
        const val COLUMN_EVENT_ID = "id"
        const val COLUMN_EVENT_NAME = "event_name"
        const val COLUMN_EVENT_DATE = "event_date"
        const val COLUMN_EVENT_TIME = "event_time"
        const val COLUMN_EVENT_DESCRIPTION = "event_description"
        const val COLUMN_EVENT_PRIORITY = "event_priority"
    }
}
