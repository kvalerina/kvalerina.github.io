package com.zybooks.projecttwoaronov

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class MainActivity : AppCompatActivity() {
    private var db: DatabaseHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Set up EncryptedSharedPreferences
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val encryptedPrefs = EncryptedSharedPreferences.create(
            this,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        // Check if the user is already logged in
        val isLoggedIn = encryptedPrefs.getBoolean(KEY_IS_LOGGED_IN, false)
        if (isLoggedIn) {
            navigateToDataDisplay()
            return
        }

        setContentView(R.layout.activity_main)
        db = DatabaseHelper(this)

        // Initialize UI components
        val usernameField = findViewById<EditText>(R.id.usernameField)
        val passwordField = findViewById<EditText>(R.id.passwordField)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val createAccountButton = findViewById<Button>(R.id.createAccountButton)

        // Handle login button click
        loginButton.setOnClickListener {
            val username = usernameField.text.toString().trim()
            val password = passwordField.text.toString().trim()

            if (!validateLoginInput(username, password)) {
                return@setOnClickListener
            }

            val userExists = db?.checkUser(username, password) ?: false
            if (userExists) {
                encryptedPrefs.edit()
                    .putBoolean(KEY_IS_LOGGED_IN, true)
                    .putString(KEY_USERNAME, username)
                    .apply()

                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                navigateToDataDisplay()
            } else {
                Toast.makeText(this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }

        // Navigate to Create Account screen
        createAccountButton.setOnClickListener {
            startActivity(Intent(this, CreateAccountActivity::class.java))
        }
    }

    // Validate user input
    private fun validateLoginInput(username: String, password: String): Boolean {
        if (username.isBlank() || password.isBlank()) {
            Toast.makeText(this, "Username and Password cannot be empty.", Toast.LENGTH_SHORT).show()
            return false
        }

        if (username.length < 3) {
            Toast.makeText(this, "Username must be at least 3 characters.", Toast.LENGTH_SHORT).show()
            return false
        }

        // Ensure strong password
        val passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}$"
        if (!password.matches(Regex(passwordPattern))) {
            Toast.makeText(this, "Password must meet complexity requirements.", Toast.LENGTH_LONG).show()
            return false
        }

        return true
    }

    // Navigate to the main event screen after login
    private fun navigateToDataDisplay() {
        startActivity(Intent(this, DailyViewActivity::class.java))
        finish()
    }

    companion object {
        private const val PREFS_NAME = "EncryptedLoginPrefs"
        private const val KEY_IS_LOGGED_IN = "isLoggedIn"
        private const val KEY_USERNAME = "username"
    }
}
