package com.zybooks.projecttwoaronov

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView

class EventAdapter(
    private val context: Context,
    private var events: MutableList<Event>,
    private val onDeleteEvent: (Event) -> Unit
) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    private var isDialogOpen = false // Prevent duplicate delete prompts

    init {
        setHasStableIds(true) // Prevents RecyclerView inconsistencies
    }

    override fun getItemId(position: Int): Long {
        return events[position].id.toLong() // Ensure unique stable IDs
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.event_card, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = events[position]

        // Set event details in the card
        holder.eventTitle.text = event.title
        holder.eventTime.text = event.time
        holder.eventPriority.text = event.priority
        holder.eventDescription.text = event.description

        // More Options Button - Show Menu
        holder.moreOptions.setOnClickListener { view ->
            if (isDialogOpen) return@setOnClickListener // Prevent multiple clicks

            val popupMenu = PopupMenu(holder.itemView.context, view)
            popupMenu.menuInflater.inflate(R.menu.event_options_menu, popupMenu.menu)

            popupMenu.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    R.id.editEvent -> {
                        // Open EditEventActivity and pass the event ID
                        val intent = Intent(holder.itemView.context, EditEventActivity::class.java).apply {
                            putExtra("EVENT_ID", event.id)
                        }
                        holder.itemView.context.startActivity(intent)
                        true
                    }
                    R.id.deleteEvent -> {
                        // Show delete confirmation
                        showDeleteConfirmation(holder, event, position)
                        true
                    }
                    else -> false
                }
            }

            popupMenu.show()
        }
    }

    // Show confirmation dialog before deleting an event
    private fun showDeleteConfirmation(holder: EventViewHolder, event: Event, position: Int) {
        if (isDialogOpen) return
        isDialogOpen = true

        val builder = AlertDialog.Builder(holder.itemView.context)
        builder.setTitle("Delete Event")
        builder.setMessage("Are you sure you want to delete '${event.title}'?")

        builder.setPositiveButton("Delete") { dialog, _ ->
            dialog.dismiss()

            // Remove the event from the list and update RecyclerView
            events.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, events.size)

            onDeleteEvent(event) // Call the delete function
            isDialogOpen = false
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
            isDialogOpen = false // Reset flag when canceled
        }

        builder.setOnDismissListener {
            isDialogOpen = false // Reset flag when dialog closed
        }

        builder.show()
    }

    override fun getItemCount(): Int = events.size

    // Update the list with new events
    fun updateEvents(newEvents: List<Event>) {
        events.clear()
        events.addAll(newEvents)
        notifyDataSetChanged()
    }

    // ViewHolder to hold each event card's views
    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val eventTitle: TextView = itemView.findViewById(R.id.eventTitle)
        val eventTime: TextView = itemView.findViewById(R.id.eventTime)
        val eventPriority: TextView = itemView.findViewById(R.id.eventPriority)
        val eventDescription: TextView = itemView.findViewById(R.id.eventDescription)
        val moreOptions: View = itemView.findViewById(R.id.moreOptions)
    }
}
