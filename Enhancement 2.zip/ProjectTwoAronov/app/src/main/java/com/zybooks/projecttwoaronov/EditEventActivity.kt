package com.zybooks.projecttwoaronov

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.content.Intent
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class EditEventActivity : AppCompatActivity() {
    private var db: DatabaseHelper? = null
    private var eventId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_event)

        db = DatabaseHelper(this)

        // Hook up UI elements to variables
        val eventNameInput = findViewById<EditText>(R.id.eventNameInput)
        val eventDateInput = findViewById<EditText>(R.id.eventDateInput)
        val eventTimeInput = findViewById<EditText>(R.id.eventTimeInput)
        val eventDescriptionInput = findViewById<EditText>(R.id.eventDescriptionInput)
        val eventPrioritySpinner = findViewById<Spinner>(R.id.eventPrioritySpinner)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val cancelButton = findViewById<Button>(R.id.cancelButton)

        //  Retrieve event ID from intent
        eventId = intent.getIntExtra("EVENT_ID", -1)
        Log.d("EditEventActivity", "Received Event ID: $eventId")

        if (eventId == -1) {
            Toast.makeText(this, "Error: Invalid Event ID", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        //  Get event details from the database
        val cursor = db?.getEventById(eventId)

        if (cursor == null || !cursor.moveToFirst()) {
            Toast.makeText(this, "Error: Event not found", Toast.LENGTH_LONG).show()
            cursor?.close() // Ensure we close it
            finish()
            return
        }

        //  Populate UI fields
        eventNameInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)))
        eventDateInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE)))
        eventTimeInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)))
        eventDescriptionInput.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESCRIPTION)))

        //  Set Priority Spinner
        val eventPriority = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_PRIORITY))
        val priorities = resources.getStringArray(R.array.event_priorities)
        val priorityIndex = priorities.indexOf(eventPriority)
        if (priorityIndex >= 0) {
            eventPrioritySpinner.setSelection(priorityIndex)
        }

        cursor.close() //  Close cursor to prevent memory leaks

        //  Date Picker
        eventDateInput.setOnClickListener {
            showDatePicker(eventDateInput)
        }

        //  Time Picker
        eventTimeInput.setOnClickListener {
            showTimePicker(eventTimeInput)
        }

        //  Save Button Click Listener
        saveButton.setOnClickListener {
            val updatedName = eventNameInput.text.toString().trim()
            val updatedDate = eventDateInput.text.toString().trim()
            val updatedTime = eventTimeInput.text.toString().trim()
            val updatedDescription = eventDescriptionInput.text.toString().trim()
            val updatedPriority = eventPrioritySpinner.selectedItem.toString()

            if (updatedName.isEmpty() || updatedDate.isEmpty() || updatedTime.isEmpty()) {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val rowsUpdated = db?.updateEvent(eventId, updatedName, updatedDate, updatedTime, updatedDescription, updatedPriority) ?: 0
            if (rowsUpdated > 0) {
                Toast.makeText(this, "Event updated successfully!", Toast.LENGTH_SHORT).show()
                finish() // Close activity and return
            } else {
                Toast.makeText(this, "Failed to update event.", Toast.LENGTH_SHORT).show()
            }
        }

        //  Cancel Button Click Listener
        cancelButton.setOnClickListener {
            val intent = Intent(this, DailyViewActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }
    }

    //  Show Date Picker
    private fun showDatePicker(eventDateInput: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = String.format(Locale.US, "%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay)
            eventDateInput.setText(formattedDate)
        }, year, month, day).show()
    }

    //  Show Time Picker
    private fun showTimePicker(eventTimeInput: EditText) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            val amPm = if (selectedHour < 12) "AM" else "PM"
            val formattedHour = if (selectedHour % 12 == 0) 12 else selectedHour % 12
            val formattedTime = String.format(Locale.US, "%02d:%02d %s", formattedHour, selectedMinute, amPm)

            eventTimeInput.setText(formattedTime)
        }, hour, minute, false).show()
    }
}
