package com.zybooks.projecttwoaronov

class EventGroup(@JvmField val date: String, @JvmField val events: List<Event>)
