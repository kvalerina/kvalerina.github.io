package com.zybooks.projecttwoaronov

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.text.SimpleDateFormat
import java.util.*

class DailyViewActivity : AppCompatActivity() {
    private var db: DatabaseHelper? = null
    private val eventList = ArrayList<Event>()
    private var eventAdapter: EventAdapter? = null
    private var currentSortOption: SortOption = SortOption.TIME_ASC

    private lateinit var searchDropdown: AutoCompleteTextView
    private lateinit var allEventsList: MutableList<Event> // Store all events for search
    private lateinit var noEventsTextView: TextView // Message when no events exist

    // Enum for sorting options
    private enum class SortOption {
        TIME_ASC, PRIORITY_ASC
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_view)

        db = DatabaseHelper(this)
        searchDropdown = findViewById(R.id.searchDropdown)
        noEventsTextView = findViewById(R.id.noEventsTextView)

        // Set up RecyclerView for today's events
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        eventAdapter = EventAdapter(this, eventList) { event: Event ->
            db?.deleteEvent(event.id)
            loadDailyEvents()
        }
        recyclerView.adapter = eventAdapter

        // Set Greeting Message
        val greetingTextView = findViewById<TextView>(R.id.greetingTextView)
        greetingTextView.text = getGreetingMessage()

        // Set Today’s Date
        val dateTextView = findViewById<TextView>(R.id.dateTextView)
        val currentDate = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
        dateTextView.text = currentDate

        // Load events
        loadDailyEvents()
        loadAllEventsForSearch()

        // Handle dropdown search selection
        searchDropdown.setOnItemClickListener { _, _, position, _ ->
            val selectedEvent = allEventsList[position]
            openEditEventScreen(selectedEvent.id)
        }

        // Navigation buttons
        findViewById<View>(R.id.imageButton7).setOnClickListener {
            startActivity(Intent(this, MonthlyViewActivity::class.java))
        }
        findViewById<View>(R.id.imageButton5).setOnClickListener {
            startActivity(Intent(this, AddEventActivity::class.java))
        }
        findViewById<View>(R.id.imageButton6).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        // Sorting button
        findViewById<View>(R.id.sortButton).setOnClickListener { view ->
            showSortMenu(view)
        }
    }

    override fun onResume() {
        super.onResume()
        loadDailyEvents() // Refresh event list when returning
    }

    private fun loadDailyEvents() {
        val newEventList = ArrayList<Event>()
        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        val cursor = db?.allEvents
        cursor?.use {
            while (it.moveToNext()) {
                try {
                    val eventDate = it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE))
                    val eventTime = it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME))

                    // Only add events for today
                    if (eventDate == currentDate) {
                        val event = Event(
                            it.getInt(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID)),
                            it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)),
                            eventDate,
                            eventTime,
                            it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESCRIPTION)),
                            it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_PRIORITY))
                        )
                        newEventList.add(event)
                    }
                } catch (e: Exception) {
                    Log.e("DailyViewActivity", "Error reading event data", e)
                }
            }
        }

        // Apply sorting
        when (currentSortOption) {
            SortOption.TIME_ASC -> newEventList.sortBy { it.time } // Sort by time (ascending)
            SortOption.PRIORITY_ASC -> newEventList.sortBy { it.priority } // Sort by priority
        }

        runOnUiThread {
            eventList.clear()
            eventList.addAll(newEventList)
            eventAdapter?.notifyDataSetChanged()

            // Show "No Events Scheduled" if the list is empty
            noEventsTextView.visibility = if (eventList.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun loadAllEventsForSearch() {
        allEventsList = ArrayList()
        val cursor = db?.allEvents

        cursor?.use {
            while (it.moveToNext()) {
                val event = Event(
                    it.getInt(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESCRIPTION)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_PRIORITY))
                )
                allEventsList.add(event)
            }
        }

        val eventNames = allEventsList.map { "${it.title} - ${it.date} at ${it.time}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, eventNames)
        searchDropdown.setAdapter(adapter)
    }

    private fun openEditEventScreen(eventId: Int) {
        val intent = Intent(this, EditEventActivity::class.java)
        intent.putExtra("EVENT_ID", eventId)
        startActivity(intent)
    }

    private fun showSortMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.sort_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.sort_time -> currentSortOption = SortOption.TIME_ASC
                R.id.sort_priority -> currentSortOption = SortOption.PRIORITY_ASC
            }
            loadDailyEvents() // Reload events with sorting applied
            true
        }
        popupMenu.show()
    }

    private fun getGreetingMessage(): String {
        // Retrieve the username from SharedPreferences
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val encryptedPrefs = EncryptedSharedPreferences.create(
            this,
            "EncryptedLoginPrefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        val username = encryptedPrefs.getString("username", "User") ?: "User"

        // Determine the greeting based on the time of day
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 5..11 -> "Good morning, $username"
            in 12..17 -> "Good afternoon, $username"
            else -> "Good evening, $username"
        }
    }
}
