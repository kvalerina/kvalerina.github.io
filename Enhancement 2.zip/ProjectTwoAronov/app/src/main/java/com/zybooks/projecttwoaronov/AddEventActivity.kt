package com.zybooks.projecttwoaronov

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import java.util.Calendar
import java.util.Locale

class AddEventActivity : AppCompatActivity() {
    private var db: DatabaseHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_event)

        // Initialize the database
        db = DatabaseHelper(this)

        // UI Components
        val eventNameInput = findViewById<EditText>(R.id.eventNameInput)
        val eventDateInput = findViewById<EditText>(R.id.eventDateInput)
        val eventTimeInput = findViewById<EditText>(R.id.eventTimeInput)
        val eventDescriptionInput = findViewById<EditText>(R.id.eventDescriptionInput)
        val eventPrioritySpinner = findViewById<Spinner>(R.id.eventPrioritySpinner)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val cancelButton = findViewById<Button>(R.id.cancelButton)

        // Handle date input click to show Date Picker
        eventDateInput.setOnClickListener {
            showDatePicker(eventDateInput)
        }

        eventTimeInput.setOnClickListener {
            showTimePicker(eventTimeInput)
        }

        // Cancel Button Click Listener
        cancelButton.setOnClickListener {
            finish()
        }

        // Handle save button click
        saveButton.setOnClickListener { _: View? ->
            val eventName = eventNameInput.text.toString().trim()
            val eventDate = eventDateInput.text.toString().trim()
            val eventTime = eventTimeInput.text.toString().trim()
            val eventDescription = eventDescriptionInput.text.toString().trim()
            val selectedPriority = eventPrioritySpinner.selectedItem.toString()

            // Validate input
            if (!validateEventDetails(eventName, eventDate, eventTime, eventDescription)) {
                return@setOnClickListener
            }

            // Add event to the database
            val result = db?.addEvent(eventName, eventDate, eventTime, eventDescription, selectedPriority)
            if (result != null && result != -1L) {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Event added successfully!",
                    Snackbar.LENGTH_LONG
                ).show()
                finish() // Close the activity
            } else {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Error adding event. Try again.",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }
    }

    // Function to show Date Picker
    private fun showDatePicker(eventDateInput: EditText) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePicker = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val formattedDate = String.format(Locale.US, "%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay)
            eventDateInput.setText(formattedDate)
            eventDateInput.clearFocus() // Prevents cursor jumping back
        }, year, month, day)

        datePicker.show()
    }

    // Function to show Time Picker
    private fun showTimePicker(eventTimeInput: EditText) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePicker = TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            val amPm = if (selectedHour < 12) "AM" else "PM"
            val formattedHour = if (selectedHour % 12 == 0) 12 else selectedHour % 12
            val formattedTime = String.format(Locale.US, "%02d:%02d %s", formattedHour, selectedMinute, amPm)

            eventTimeInput.setText(formattedTime)
            eventTimeInput.clearFocus() // Prevents cursor jumping back
        }, hour, minute, false)

        timePicker.show()
    }

    // Validates the event details before saving or updating an event
    private fun validateEventDetails(
        eventName: String,
        eventDate: String,
        eventTime: String,
        eventDescription: String
    ): Boolean {
        // Check if event name is empty
        if (eventName.isBlank()) {
            showSnackbar("Event name cannot be empty.")
            return false
        }
        // Check if event date is empty
        if (eventDate.isBlank() || !isValidDateFormat(eventDate)) {
            showSnackbar("Invalid date format. Use YYYY-MM-DD.")
            return false
        }
        //Check if event time is empty
        if (eventTime.isBlank() || !isValidTimeFormat(eventTime)) {
            showSnackbar("Invalid time format. Use HH:MM AM/PM.")
            return false
        }
        // Check if event description is empty
        if (eventDescription.isBlank()) {
            showSnackbar("Event description cannot be empty.")
            return false
        }
        // All validations passed
        return true
    }

    // Display snackbar message
    private fun showSnackbar(message: String) {
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG).show()
    }

    // Checks if the provided dates match the expected format
    private fun isValidDateFormat(date: String): Boolean {
        val datePattern = "^\\d{4}-\\d{2}-\\d{2}$" // YYYY-MM-DD
        return Regex(datePattern).matches(date)
    }

    // Checks if the provided times match the expected format
    private fun isValidTimeFormat(time: String): Boolean {
        val timePattern = "^(0[1-9]|1[0-2]):[0-5][0-9]\\s?(?i)(AM|PM)$" // HH:MM AM/PM
        return Regex(timePattern).matches(time)
    }
}
