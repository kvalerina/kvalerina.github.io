package com.zybooks.projecttwoaronov

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class MonthlyViewActivity : AppCompatActivity() {
    private var db: DatabaseHelper? = null
    private val eventList = mutableListOf<Event>()
    private lateinit var eventAdapter: EventAdapter
    private lateinit var selectedDateTextView: TextView
    private lateinit var noEventsTextView: TextView
    private lateinit var searchDropdown: AutoCompleteTextView
    private lateinit var allEventsList: MutableList<Event>

    private var selectedDate: String = ""
    private var currentSortOption: SortOption = SortOption.TIME_ASC

    // Enum for sorting options
    private enum class SortOption {
        TIME_ASC, PRIORITY_ASC
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monthly_view)

        db = DatabaseHelper(this)

        // Initialize UI components
        searchDropdown = findViewById(R.id.searchDropdown)
        selectedDateTextView = findViewById(R.id.selectedDateTextView)
        noEventsTextView = findViewById(R.id.noEventsTextView)

        // Set up RecyclerView for event list
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        eventAdapter = EventAdapter(this, eventList) { event ->
            db?.deleteEvent(event.id)
            loadEventsForDate(selectedDate) // Refresh events after deletion
        }
        recyclerView.adapter = eventAdapter

        // Set up CalendarView to select dates
        val calendarView = findViewById<CalendarView>(R.id.calendarView)
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            selectedDateTextView.text = formatDate(selectedDate)
            loadEventsForDate(selectedDate) // Load events for selected date
        }

        // Load all events into the search dropdown
        loadAllEventsForSearch()

        // Handle dropdown search selection
        searchDropdown.setOnItemClickListener { _, _, position, _ ->
            val selectedEvent = allEventsList[position]
            openEditEventScreen(selectedEvent.id)
        }

        // Sorting button listener
        findViewById<View>(R.id.sortButton).setOnClickListener { view ->
            showSortMenu(view)
        }

        // Load current month by default
        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        selectedDate = currentDate
        selectedDateTextView.text = formatDate(currentDate)
        loadEventsForDate(selectedDate)

        // Footer Button Listeners
        findViewById<View>(R.id.imageButton4).setOnClickListener {
            startActivity(Intent(this, DailyViewActivity::class.java))
        }
        findViewById<View>(R.id.imageButton7).setOnClickListener {
            startActivity(Intent(this, MonthlyViewActivity::class.java))
        } // Refresh Monthly View
        findViewById<View>(R.id.imageButton5).setOnClickListener {
            startActivity(Intent(this, AddEventActivity::class.java))
        }
        findViewById<View>(R.id.imageButton6).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    // Load all events into the search dropdown
    private fun loadAllEventsForSearch() {
        allEventsList = ArrayList()
        val cursor = db?.allEvents

        cursor?.use {
            while (it.moveToNext()) {
                val event = Event(
                    it.getInt(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESCRIPTION)),
                    it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_PRIORITY))
                )
                allEventsList.add(event)
            }
        }

        // Convert event list to dropdown items
        val eventNames = allEventsList.map { "${it.title} - ${it.date} at ${it.time}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, eventNames)
        searchDropdown.setAdapter(adapter)
    }

    // Load events for the selected date
    private fun loadEventsForDate(date: String) {
        eventList.clear()

        val cursor = db?.allEvents
        cursor?.use {
            while (it.moveToNext()) {
                try {
                    val eventDate = it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE))
                    if (eventDate == date) {
                        val event = Event(
                            it.getInt(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_ID)),
                            it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME)),
                            eventDate,
                            it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TIME)),
                            it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DESCRIPTION)),
                            it.getString(it.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_PRIORITY))
                        )
                        eventList.add(event)
                    }
                } catch (e: Exception) {
                    Log.e("MonthlyViewActivity", "Error reading event data", e)
                }
            }
        }

        sortAndDisplayEvents() // Apply sorting
    }

    // Show sorting menu
    private fun showSortMenu(view: View) {
        val popupMenu = PopupMenu(this, view)
        popupMenu.menuInflater.inflate(R.menu.sort_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                R.id.sort_time -> currentSortOption = SortOption.TIME_ASC
                R.id.sort_priority -> currentSortOption = SortOption.PRIORITY_ASC
            }
            sortAndDisplayEvents()
            true
        }
        popupMenu.show()
    }

    // Sort and display events
    private fun sortAndDisplayEvents() {
        when (currentSortOption) {
            SortOption.TIME_ASC -> {
                eventList.sortBy { it.time }
            }
            SortOption.PRIORITY_ASC -> {
                eventList.sortBy { it.priority }
            }
        }

        // Show or hide "No Events Scheduled" message
        noEventsTextView.visibility = if (eventList.isEmpty()) View.VISIBLE else View.GONE

        eventAdapter.notifyDataSetChanged()
    }

    // Function to open edit event screen
    private fun openEditEventScreen(eventId: Int) {
        val intent = Intent(this, EditEventActivity::class.java)
        intent.putExtra("EVENT_ID", eventId)
        startActivity(intent)
    }

    // Function to format date properly
    private fun formatDate(date: String): String {
        return try {
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val outputFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
            val parsedDate = inputFormat.parse(date)
            parsedDate?.let { outputFormat.format(it) } ?: date
        } catch (e: Exception) {
            Log.e("MonthlyViewActivity", "Date parsing error", e)
            date
        }
    }
}
