package com.zybooks.projecttwoaronov

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class ChangePasswordActivity : AppCompatActivity() {
    private var db: DatabaseHelper? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        db = DatabaseHelper(this)

        // UI Components
        val oldPasswordInput = findViewById<EditText>(R.id.oldPasswordInput)
        val newPasswordInput = findViewById<EditText>(R.id.newPasswordInput)
        val confirmPasswordInput = findViewById<EditText>(R.id.confirmPasswordInput)
        val savePasswordButton = findViewById<Button>(R.id.savePasswordButton)
        val cancelButton = findViewById<Button>(R.id.cancelButton)

        // Retrieve username from EncryptedSharedPreferences
        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val encryptedPrefs = EncryptedSharedPreferences.create(
            this,
            "EncryptedLoginPrefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        val username = encryptedPrefs.getString("username", "") ?: ""
        Log.d("ChangePasswordActivity", "Retrieved username: $username")

        // If no username is found, exit the activity
        if (username.isEmpty()) {
            Toast.makeText(this, "No logged-in user found. Please log in again.", Toast.LENGTH_LONG)
                .show()
            finish()
            return
        }

        // Cancel Button Functionality
        cancelButton.setOnClickListener {
            finish() // Closes this activity and returns to the previous screen
        }

        // Save button: Validate inputs and update the password
        savePasswordButton.setOnClickListener { _: View? ->
            val oldPassword = oldPasswordInput.text.toString().trim()
            val newPassword = newPasswordInput.text.toString().trim()
            val confirmPassword = confirmPasswordInput.text.toString().trim()

            if (oldPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "All fields are required.", Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }

            if (newPassword != confirmPassword) {
                Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }

            // Validate old password and update
            if (db!!.checkUser(username, oldPassword)) {
                val rowsUpdated = db!!.updateUserPassword(username, newPassword)
                if (rowsUpdated > 0) {
                    Toast.makeText(
                        this,
                        "Password changed successfully!",
                        Toast.LENGTH_LONG
                    ).show()
                    finish()
                } else {
                    Toast.makeText(
                        this,
                        "Failed to update password.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(this, "Old password is incorrect.", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}
