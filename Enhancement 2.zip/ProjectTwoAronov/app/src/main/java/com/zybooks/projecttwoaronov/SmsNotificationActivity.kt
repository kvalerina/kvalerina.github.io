package com.zybooks.projecttwoaronov

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SmsNotificationActivity : AppCompatActivity() {
    private var permissionMessage: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms_notification)

        // Initialize UI elements
        permissionMessage = findViewById(R.id.permissionMessage)
        val grantPermissionButton = findViewById<Button>(R.id.grantPermissionButton)
        val skipPermissionButton = findViewById<Button>(R.id.skipPermissionButton)

        // Handle "Grant Permission" button click
        grantPermissionButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED
            ) {
                // Permission already granted
                permissionMessage?.text = getString(R.string.permission_already_granted)
                Toast.makeText(
                    this,
                    getString(R.string.permission_already_granted),
                    Toast.LENGTH_SHORT
                ).show()
                sendSmsNotification() // Trigger SMS sending
            } else {
                // Request permission
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.SEND_SMS),
                    SMS_PERMISSION_REQUEST_CODE
                )
            }
        }

        // Skip permission and continue using the app
        skipPermissionButton.setOnClickListener {
            Toast.makeText(
                this,
                "SMS permissions denied. You can enable it in Settings to use SMS features.",
                Toast.LENGTH_LONG
            ).show()
            goToMainApp()
        }
    }

    // Handle permission request results
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                permissionMessage?.let {
                    it.text = getString(R.string.permission_granted)
                }
                Toast.makeText(
                    this,
                    "Permission granted. SMS notifications are now enabled.",
                    Toast.LENGTH_SHORT
                ).show()
                sendSmsNotification() // Trigger SMS sending
            } else {
                // Permission denied
                permissionMessage?.let {
                    it.text = getString(R.string.permission_denied)
                }
                Toast.makeText(
                    this,
                    "Permission denied. The app will function without SMS notifications.",
                    Toast.LENGTH_LONG
                ).show()
                goToMainApp()
            }
        }
    }

    // Function to send an SMS notification
    private fun sendSmsNotification() {
        try {
            val smsManager = getSystemService(SmsManager::class.java)

            // Example phone number
            val phoneNumber = "+1234567890"

            // Example static message
            val message = "Permission Granted. Your event notifications are active."

            // Send SMS
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            // Use Log.e for logging
            Log.e("SmsNotificationActivity", "Failed to send SMS notification", e)

            // Notify the user about the failure
            Toast.makeText(this, "Failed to send SMS notification.", Toast.LENGTH_SHORT).show()
        }
    }

    // Navigate back to the main app
    private fun goToMainApp() {
        val intent = Intent(this@SmsNotificationActivity, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    companion object {
        private const val SMS_PERMISSION_REQUEST_CODE = 100
    }
}
