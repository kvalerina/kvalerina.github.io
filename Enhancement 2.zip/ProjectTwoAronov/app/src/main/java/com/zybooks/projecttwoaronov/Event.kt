package com.zybooks.projecttwoaronov

data class Event(
    val id: Int,
    val title: String,
    val date: String,
    val time: String,
    val description: String,
    val priority: String
)
