package com.zybooks.projecttwoaronov

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar

const val SMS_PERMISSION_REQUEST_CODE = 100

class CreateAccountActivity : AppCompatActivity() {
    private var db: DatabaseHelper? = null
    private var pendingUsername: String? = null
    private var pendingPassword: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_account)

        // Initialize the database
        db = DatabaseHelper(this)

        // UI Components
        val usernameInput = findViewById<EditText>(R.id.usernameInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val confirmPasswordInput = findViewById<EditText>(R.id.confirmPasswordInput)
        val createAccountButton = findViewById<Button>(R.id.createAccountButton)

        // Set up button listener
        createAccountButton.setOnClickListener { _: View? ->
            val username = usernameInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()
            val confirmPassword = confirmPasswordInput.text.toString().trim()

            // Validate input fields
            if (!validateLoginInput(username, password)) {
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Passwords do not match.",
                    Snackbar.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            // Check if username already exists
            if (db!!.checkUser(username, "")) { // Check only for the username
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Username already exists. Please choose another.",
                    Snackbar.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            // Save username and password before requesting SMS permission
            pendingUsername = username
            pendingPassword = password

            // Request SMS permission if needed
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.SEND_SMS),
                    SMS_PERMISSION_REQUEST_CODE
                )
            } else {
                createUserAccount(pendingUsername, pendingPassword)
            }
        }
    }

    // Handle SMS permission result
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "SMS Permission granted.",
                    Snackbar.LENGTH_SHORT
                ).show()
                createUserAccount(pendingUsername, pendingPassword)
            } else {
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Permission denied. Proceeding without SMS notifications.",
                    Snackbar.LENGTH_SHORT
                ).show()
                createUserAccount(pendingUsername, pendingPassword)
            }
        }
    }

    // Create a new user account in the database
    private fun createUserAccount(username: String?, password: String?) {
        if (username == null || password == null) {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Invalid username or password.",
                Snackbar.LENGTH_SHORT
            ).show()
            return
        }
        val result = db!!.addUser(username, password)
        if (result != -1L) {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Account created successfully!",
                Snackbar.LENGTH_LONG
            ).show()
            sendWelcomeSms(username)

            // Redirect to main screen
            val intent = Intent(this@CreateAccountActivity, MainActivity::class.java)
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        } else {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Error creating account. Try again.",
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    // Send a welcome SMS (if permission is granted)
    private fun sendWelcomeSms(username: String?) {
        try {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                val smsManager = applicationContext.getSystemService(SmsManager::class.java)

                val message =
                    "Welcome to Event Planner, $username! Your account has been created successfully and notifications are enabled."
                val phoneNumber = "+1234567890"

                smsManager?.sendTextMessage(phoneNumber, null, message, null, null)
                Log.d("CreateAccountActivity", "SMS sent to: $phoneNumber")
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Welcome SMS sent!",
                    Snackbar.LENGTH_SHORT
                ).show()
            } else {
                Log.e("CreateAccountActivity", "SMS permission not granted.")
            }
        } catch (e: Exception) {
            Log.e("CreateAccountActivity", "Failed to send SMS.", e)
            Snackbar.make(
                findViewById(android.R.id.content),
                "Failed to send SMS. Please try again.",
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    // Validate username and password input
    private fun validateLoginInput(username: String, password: String): Boolean {
        if (username.isBlank() || password.isBlank()) {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Username and Password cannot be empty.",
                Snackbar.LENGTH_LONG
            ).show()
            return false
        }

        if (username.length < 3) {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Username must be at least 3 characters.",
                Snackbar.LENGTH_LONG
            ).show()
            return false
        }

        val passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}$"
        val passwordRegex = Regex(passwordPattern)

        // Password restrictions
        if (!passwordRegex.matches(password)) {
            Snackbar.make(
                findViewById(android.R.id.content),
                "Password must be at least 8 characters and include at least 1 uppercase letter, 1 lowercase letter, 1 digit, and 1 special character.",
                Snackbar.LENGTH_INDEFINITE
            ).setAction("OK") {
                // Dismiss when the user clicks "OK"
            }.also { snackbar ->
                val snackbarView = snackbar.view
                val snackbarText = snackbarView.findViewById<TextView>(com.google.android.material.R.id.snackbar_text)
                snackbarText.maxLines = 5 // Allow up to 5 lines of text
            }.show()
            return false
        }

        return true
    }
}
